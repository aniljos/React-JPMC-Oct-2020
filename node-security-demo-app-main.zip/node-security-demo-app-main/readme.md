# Node Express
#### See the package.json for the scrips to execute.


```
